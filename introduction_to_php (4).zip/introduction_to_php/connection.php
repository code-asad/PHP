<?php 

$server = "mysql:host=localhost;dbname=aptech_inc";
$user ="root";
$password=""; 

$pdo = new PDO($server,$user,$password);


?>