<?php 
include("connection.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <title>Connection</title>
</head>
<body>

<div class="container mt-5 ">

<?php 
 
 $query = $pdo-> query("select * from faculty");
 $result = $query-> fetchALL(PDO::FETCH_ASSOC);
 foreach($result as $products){
    ?>
<table class="table table-striped">
    <tr>
        <td><?php echo $products["name"] ?></td>
        <td> <?php echo $products["email"] ?></td>
        <td> <?php echo $products["salary"]?></td>
    </tr>
</table>
<?php
 }
?>
</div>

</body>
</html>