<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        <?php   
        $name = "asa";
        $color = "green";
        $color1 = "red";
        if($name == "asad"){
            echo "<h1 style='color:$color'> welcome " . $name . "</h1>";
        }
        else {
            echo "<h1 style='color:$color1'>name not matched" . "</h1>";
        } 
        ?>
    </body>
    </html>
</body>
</html>