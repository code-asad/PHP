<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>

<div class="container mt-3">

<form action="mark_result.php" method="post">

<div class="form-group">
  <label for="">Name</label>
  <input type="text" name="name" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">Father Name</label>
  <input type="text" name="f_name" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">Class</label>
  <input type="text" name="class" id="" class="form-control" placeholder="" aria-describedby="helpId">
</div>
<div class="form-group">
  <label for="">Roll Number</label>
  <input type="number" name="r_number" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">Mathematics</label>
  <input type="number" name="mathematics" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">English</label>
  <input type="number" name="english" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">Urdu</label>
  <input type="number" name="urdu" id="" class="form-control" placeholder="" aria-describedby="helpId">
</div>
<div class="form-group">
  <label for="">Physics</label>
  <input type="number" name="physics" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">Chemistry</label>
  <input type="number" name="chemistry" id="" class="form-control" placeholder="" aria-describedby="helpId">
</div>
<div class="form-group">
  <label for="">Islamiat</label>
  <input type="number" name="islamiat" id="" class="form-control" placeholder="" aria-describedby="helpId">
</div>
<div class="form-group">
  <label for="">Computer</label>
  <input type="number" name="computer" id="" class="form-control" placeholder="" aria-describedby="helpId">
</div>

<div class="form-group">
  <label for="">Com_practicle</label>
  <input type="number" name="com_practicle" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">phy_practicle</label>
  <input type="number" name="phy_practicle" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<div class="form-group">
  <label for="">Chy_practicle</label>
  <input type="number" name="che_practicle" id="" class="form-control" placeholder="" aria-describedby="helpId">

</div>
<input type="submit" class="btn btn-dark" name="sub" value="submit">
</div>
</div>


</form>
</div>
</body>
</html>