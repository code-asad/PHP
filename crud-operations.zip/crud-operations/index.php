<?php 

$name = 'asad' ;
$age = 19 ;
// echo "name is " . $name . " and age is" . $age ; 
// echo $name, $age; 
 ?>  


<!-- <h1> <?php ?></h1>  -->

<?php 
$name = "shahid" ; 

print str_word_count($name) 

?>

