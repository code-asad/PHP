<?php 

$server = "mysql:host=localhost;dbname=test";
$user ="root";
$password=""; 

$pdo = new PDO($server,$user,$password);


?>